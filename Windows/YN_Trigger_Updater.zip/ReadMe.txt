INSTALLATION:

1. Run YN_Trigger_Updater_Setup.exe to install the driver and software.

2. Turn off the product you want to update. Keep pressing mode key and turn on it again. The screen will show current firmware version and some update characters. 

3. Connect the device to your PC via usb cable.

5. Run YN_Trigger_Updater_EN.exe, click Browse to select the new firmware (*.dfu), wait a few seconds until the update button is enabled. Then click update button to begin the upgrade.

6. When the upgrade is done, the product will be reset automatically.