V1.34 2017-08-28
Fix the upgrade exception problem;
Other improvement.


V1.33
Improve the compatibility with YN686EX-RT��
other improvement.
